<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Password Reset</title>
    <!-- bootstrap css -->
    <link rel="stylesheet" href="{{asset('assets/css/bootstrap.min.css')}}">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('assets/vendors/datatables/css/datatables.bootstrap.css')}}">
    <link rel="stylesheet" href="{{asset('assets/vendors/datatables/css/datatables.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/vendors/scrollbar/scroll.css')}}">
    <link rel="stylesheet" href="{{asset('assets/admin/css/admin.css')}}">
    <!-- main stylesheet css -->
    <link rel="stylesheet" href="{{asset('assets/css/style.css')}}">
    <script src="{{asset('assets/js/jquery.min.js')}}"></script>
    <style>
        .forget-password{
            margin: auto;
            width: 470px;
            text-align: left;
            padding: 50px 40px 60px;
            border: 1px solid #e9edef;
            border-radius: 5px;
            box-shadow: 0px 0px 41px rgba(0, 192, 239, 0.15);
            text-align: center;
        }
        
        .forget-password input.form-control{
            border: 1px solid #f5efef;
            background: #fafafa;
            margin-bottom: 20px;
            text-align: left;
            height: 45px;
        }
        .forget-password .btn.btn-info.btn-block{
            margin-top: 10px;
            font-weight: 600;
            border-radius: 2px;
            border: solid;
            background: #2a90ea;
            height: 45px;
            outline: none;
            box-shadow: none;
            border: none;
            transition: all 0.3s ease 0s;
        }
        .forget-pas{
            height: 100vh;
            display: flex;
        }
        @media (max-width: 767.98px) {
            .forget-password{
                width: 300px;
                padding: 30px 20px 40px;
            }
        }
    </style>
</head>
<body>
{{--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">--}}
        <div class="forget-pas">
            <div class="forget-password">
                <h3><i class="fa fa-lock fa-4x"></i></h3>
                <h2>Forgot Password?</h2>
                <p>You can reset your password here.</p>
                    @if($message=Session::get('message'))
                         <h4 class="text-center text-success">{{ $message }} </h4>
                    @endif
                    {{Form::open(['route' => 'sendPasswordResetToken'])}}
                        <div {{ $errors->has('email') ? 'has-error' : '' }}">
                                <input id="email" name="email" placeholder="Email address" class="form-control"  type="email">
                            
                            <span class="text-danger">{{ $errors->has('email') ? $errors->first('email') : '' }}</span>
                            <input name="recover-submit" class="btn btn-info btn-block" value="Send Reset Password Link" type="submit">
                        </div>
                    {{Form::close()}}
            </div>
        </div>
        
        <script src="{{asset('assets/js/bootstrap.min.js')}}"></script>
        <script src="{{asset('assets/js/dc-custom.js')}}"></script>
        <script src="{{asset('assets/vendors/datatables/js/datatable.min.js')}}"></script>
        <script src="{{asset('assets/vendors/datatables/js/datatables.min.js')}}"></script>
        <script src="{{asset('assets/vendors/datatables/js/bootstrap/datatables.bootstrap.js')}}"></script>
        <script src="{{asset('assets/vendors/datatables/js/table-datatables-responsive.js')}}"></script>
        {{--<script src="https://maps.googleapis.com/maps/api/js"></script>--}}
        {{--			<script src="{{asset('assets/vendors/gmap/map.custom.js')}}"></script>--}}
        <script src="{{asset('assets/admin/js/admin.js')}}"></script>
        <script src="{{asset('assets/vendors/scrollbar/jquery.nicescroll.min.js')}}')}}"></script>
    </body>
</html>
